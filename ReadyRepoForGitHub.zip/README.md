
Ready Repo for GitHub Upload
===========================

This repo contains a minimal Android project (WebView) wrapping a demo casino web app.
- Edit web assets in `app/src/main/assets/www/` to add features.
- Push to GitHub `main` branch; the Actions workflow will attempt to build an APK.

IMPORTANT for iPhone uploads:
- Unzip this archive on your iPhone and upload the extracted files using GitHub's "Upload files" (Request Desktop Site).
- If upload is difficult, use the "Working Copy" iOS app to push files to GitHub.
