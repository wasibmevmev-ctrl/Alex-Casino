rootProject.name = "CasinoPracticeAndroid"
include(":app")
