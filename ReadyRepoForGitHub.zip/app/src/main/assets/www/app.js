// Simple demo. FEATURES: add more features by editing app.js and index.html
const main = document.getElementById('main');
const balanceEl = document.getElementById('balance');
let balance = Number(localStorage.getItem('balance')||1000);
balanceEl.textContent = balance;
function updateBalance(delta){ balance = Math.max(0,balance+delta); localStorage.setItem('balance',balance); balanceEl.textContent=balance; }
document.getElementById('btnColor').onclick = ()=>{ colorTradingUI(); };
document.getElementById('btnSlots').onclick = ()=>{ main.innerHTML='<p>Slots coming soon — add in app.js (TODO)</p>'; };
document.getElementById('btnRoulette').onclick = ()=>{ main.innerHTML='<p>Roulette coming soon — add in app.js (TODO)</p>'; };
document.getElementById('btnBlack').onclick = ()=>{ main.innerHTML='<p>Blackjack coming soon — add in app.js (TODO)</p>'; };

function colorTradingUI(){
  main.innerHTML = `
    <h2>Color Trading (Practice)</h2>
    <label>Bet: <input id="bet" type="number" value="50"></label>
    <select id="choice"><option value="red">Red</option><option value="green">Green</option><option value="blue">Blue</option></select>
    <button id="go">Predict</button>
    <div id="res"></div>
    <p><!-- TODO: Add feature: allow user to set probabilities and payouts via UI --></p>
  `;
  document.getElementById('go').onclick = ()=>{
    const bet = Math.max(10,Number(document.getElementById('bet').value||0));
    if(bet>balance){ alert('Insufficient'); return; }
    updateBalance(-bet);
    const r=Math.random();
    let result='red'; if(r<0.45) result='red'; else if(r<0.9) result='green'; else result='blue';
    const pick = document.getElementById('choice').value;
    let mult=0; if(pick===result) mult = (result==='blue')?3:2;
    const res = document.getElementById('res');
    if(mult>0){ const win = bet*mult; updateBalance(win); res.textContent = `Win ${win}`; } else res.textContent = 'Lost';
  };
}
